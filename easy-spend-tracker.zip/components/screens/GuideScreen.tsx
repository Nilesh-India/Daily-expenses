import React, { useRef, useState } from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import Button from '../ui/Button';
import Card from '../ui/Card';

// Helper components for the guide
const ArrowIcon = () => <svg className="w-10 h-10 text-primary-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 9l4 4m0 0l-4 4m4-4H3" /></svg>;
const DownloadIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>;
const LandmarkIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" x2="21" y1="22" y2="22"/><line x1="6" x2="6" y1="18" y2="11"/><line x1="10" x2="10" y1="18" y2="11"/><line x1="14" x2="14" y1="18" y2="11"/><line x1="18" x2="18" y1="18" y2="11"/><polygon points="12 2 2 7 12 12 22 7 12 2"/></svg>;
const PencilIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>;
const PlusIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" x2="12" y1="5" y2="19"/><line x1="5" x2="19" y1="12" y2="12"/></svg>;


const MockScreenshot: React.FC<{ children: React.ReactNode, className?: string }> = ({ children, className }) => (
    <div className={`mt-4 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 bg-white dark:bg-gray-800/50 relative overflow-hidden ${className}`}>
        {children}
    </div>
);

const Annotation: React.FC<{ text: string, className?: string }> = ({ text, className }) => (
    <div className={`flex items-center gap-2 ${className}`}>
        <ArrowIcon />
        <p className="text-lg font-semibold text-primary-600 dark:text-primary-400 bg-primary-100/50 dark:bg-primary-900/50 p-2 rounded-lg">{text}</p>
    </div>
);

const GuideScreen = () => {
    const guideRef = useRef<HTMLDivElement>(null);
    const [isDownloading, setIsDownloading] = useState(false);

    const handleDownloadPdf = () => {
        const guideElement = guideRef.current;
        if (!guideElement) {
            console.error("Guide element not found");
            return;
        }
        setIsDownloading(true);

        const isDark = document.documentElement.classList.contains('dark');
        
        html2canvas(guideElement, {
            scale: 2,
            useCORS: true,
            backgroundColor: isDark ? '#111827' : '#f9fafb', // Manually set background
            windowWidth: guideElement.scrollWidth,
            windowHeight: guideElement.scrollHeight,
        }).then(canvas => {
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF({
                orientation: 'portrait',
                unit: 'px',
                format: [canvas.width, canvas.height]
            });

            pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
            pdf.save('easy-spend-tracker-guide.pdf');
            setIsDownloading(false);
        }).catch(err => {
            console.error("Error generating PDF:", err);
            setIsDownloading(false);
        });
    };

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white">App Guide</h1>
                <Button onClick={handleDownloadPdf} disabled={isDownloading}>
                    <DownloadIcon /> {isDownloading ? 'Downloading...' : 'Download as PDF'}
                </Button>
            </div>
            <div ref={guideRef} className="space-y-8 p-0 sm:p-4 rounded-lg">

                <Card className="p-6">
                    <h2 className="text-2xl font-bold mb-2">1. The Home Screen</h2>
                    <p className="text-gray-600 dark:text-gray-300">This is your main dashboard. You can see your total balance, monthly summaries, and navigate to your accounts.</p>
                    <MockScreenshot>
                        <div className="text-center">
                            <h2 className="text-lg font-medium text-gray-500 dark:text-gray-400">Total Balance</h2>
                            <p className="text-4xl font-bold text-gray-900 dark:text-white mt-1">₹50,000.00</p>
                        </div>
                    </MockScreenshot>
                     <div className="mt-4 flex flex-col md:flex-row items-center justify-center gap-4 text-center">
                        <Annotation text="Click an account to see its ledger" />
                        <Card className="p-4 flex items-center justify-between w-full max-w-sm">
                            <div className="flex items-center gap-4">
                                <span className="text-primary-500"><LandmarkIcon /></span>
                                <span className="font-semibold text-lg">Bank 1</span>
                            </div>
                            <span className="font-bold text-lg">₹25,000.00</span>
                        </Card>
                    </div>
                </Card>

                <Card className="p-6">
                    <h2 className="text-2xl font-bold mb-2">2. Managing Accounts</h2>
                    <p className="text-gray-600 dark:text-gray-300">You can add new accounts, or edit and delete existing ones.</p>
                    <div className="mt-4 flex flex-col md:flex-row items-center justify-center gap-4 text-center">
                         <Button variant="secondary" className="!py-1.5 !px-3 text-sm">
                            <PencilIcon />
                            <span className="ml-2">Manage</span>
                         </Button>
                        <Annotation text="Click 'Manage' to open the account editor." />
                    </div>
                    <MockScreenshot>
                        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Add New Account</h3>
                        <div className="flex items-center gap-2">
                            <input type="text" placeholder="New account name" className="w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md p-2" disabled/>
                            <Button>Add Account</Button>
                        </div>
                        <Annotation text="Add a new bank or wallet here." className="mt-8"/>
                    </MockScreenshot>
                </Card>
                
                <Card className="p-6">
                    <h2 className="text-2xl font-bold mb-2">3. Adding Income & Expenses</h2>
                    <p className="text-gray-600 dark:text-gray-300">From any account ledger, you can add income, expenses, or transfers.</p>
                     <MockScreenshot>
                        <div className="flex gap-4">
                            <Button className="flex-1"><PlusIcon /> Add Income</Button>
                        </div>
                         <Annotation text="Click to add income like salary or gifts." className="mt-8"/>
                    </MockScreenshot>
                    <MockScreenshot>
                         <h1 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Add New Expense</h1>
                          <div className="space-y-2">
                             <input type="number" placeholder="Amount" className="w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md p-2" disabled/>
                             <input type="text" placeholder="e.g., Lunch" className="w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md p-2" disabled/>
                         </div>
                         <Annotation text="Add expenses from the 'All Expenses' screen." className="mt-8"/>
                    </MockScreenshot>
                </Card>

                <Card className="p-6">
                    <h2 className="text-2xl font-bold mb-2">4. Backup & Restore</h2>
                    <p className="text-gray-600 dark:text-gray-300">The app works offline. To keep your data safe, download a backup file and save it to a cloud service like Google Drive.</p>
                    <MockScreenshot className="flex flex-col items-center">
                        <Button className="w-full sm:w-auto"><DownloadIcon/> Manual Backup</Button>
                        <Annotation text="Click here to download your data file." className="mt-8"/>
                    </MockScreenshot>
                </Card>

            </div>
        </div>
    );
};

export default GuideScreen;