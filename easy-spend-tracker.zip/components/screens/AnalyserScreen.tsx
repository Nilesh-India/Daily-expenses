import React, { useMemo, useState } from 'react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { useData } from '../../context/DataContext';
import { TransactionType } from '../../types';
import Card from '../ui/Card';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#AF19FF', '#FF1943', '#19D7FF'];

const AnalyserScreen: React.FC = () => {
  const { transactions, categories } = useData();
  const [timeRange, setTimeRange] = useState<'daily' | 'weekly' | 'monthly'>('monthly');

  const filteredTransactions = useMemo(() => {
    const now = new Date();
    return transactions.filter(t => {
      const tDate = new Date(t.date);
      if (timeRange === 'monthly') {
        return tDate.getFullYear() === now.getFullYear() && tDate.getMonth() === now.getMonth();
      }
      if (timeRange === 'weekly') {
        const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        return tDate >= oneWeekAgo;
      }
      if (timeRange === 'daily') {
        return tDate.toDateString() === now.toDateString();
      }
      return true;
    });
  }, [transactions, timeRange]);

  const expenseByCategory = useMemo(() => {
    const data = filteredTransactions
      .filter(t => 
        t.type === TransactionType.EXPENSE || 
        (t.type === TransactionType.TRANSFER && t.description.includes('to'))
      )
      .reduce((acc, t) => {
        let key: string;
        if (t.type === TransactionType.EXPENSE) {
          key = categories.find(c => c.id === t.categoryId)?.name || 'Uncategorized';
        } else {
          // This must be a transfer out
          key = 'Transfers Out';
        }
        acc[key] = (acc[key] || 0) + t.amount;
        return acc;
      }, {} as { [key: string]: number });

    return Object.entries(data).map(([name, value]) => ({ name, value }));
  }, [filteredTransactions, categories]);

  const monthlyTrends = useMemo(() => {
      const trends: { [key: string]: { income: number; expense: number } } = {};
      const now = new Date();
      const sixMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 5, 1);

      transactions.filter(t => new Date(t.date) >= sixMonthsAgo).forEach(t => {
          const month = new Date(t.date).toLocaleString('default', { month: 'short', year: '2-digit' });
          if (!trends[month]) {
              trends[month] = { income: 0, expense: 0 };
          }
          if (t.type === TransactionType.INCOME || (t.type === TransactionType.TRANSFER && t.description.includes('from'))) {
              trends[month].income += t.amount;
          } else if (t.type === TransactionType.EXPENSE || (t.type === TransactionType.TRANSFER && t.description.includes('to'))) {
              trends[month].expense += t.amount;
          }
      });
      
      return Object.entries(trends).map(([name, values]) => ({ name, ...values })).reverse();
  }, [transactions]);

  const totalIncome = filteredTransactions
    .filter(t => t.type === TransactionType.INCOME || (t.type === TransactionType.TRANSFER && t.description.includes('from')))
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpense = filteredTransactions
    .filter(t => t.type === TransactionType.EXPENSE || (t.type === TransactionType.TRANSFER && t.description.includes('to')))
    .reduce((sum, t) => sum + t.amount, 0);

  const surplus = totalIncome - totalExpense;
  const formatCurrency = (amount: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(amount);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Spend Analyser</h1>
      <div className="flex gap-2">
        {(['daily', 'weekly', 'monthly'] as const).map(range => (
          <button key={range} onClick={() => setTimeRange(range)} className={`px-3 py-1 text-sm font-semibold rounded-full capitalize ${timeRange === range ? 'bg-primary-600 text-white' : 'bg-gray-200 dark:bg-gray-700'}`}>
            {range}
          </button>
        ))}
      </div>
      
      <Card className="p-4">
        <h3 className="font-bold text-lg mb-2">Summary ({timeRange})</h3>
        <div className="grid grid-cols-3 gap-4 text-center">
            <div>
                <p className="text-sm text-gray-500">Income</p>
                <p className="font-semibold text-lg text-income">{formatCurrency(totalIncome)}</p>
            </div>
            <div>
                <p className="text-sm text-gray-500">Expense</p>
                <p className="font-semibold text-lg text-expense">{formatCurrency(totalExpense)}</p>
            </div>
            <div>
                <p className="text-sm text-gray-500">Surplus/Deficit</p>
                <p className={`font-semibold text-lg ${surplus >= 0 ? 'text-income' : 'text-expense'}`}>{formatCurrency(surplus)}</p>
            </div>
        </div>
      </Card>
      
      <div className="grid md:grid-cols-2 gap-6">
          <Card className="p-4">
            <h3 className="font-bold text-lg mb-4 text-center">Outflow by Category</h3>
            {expenseByCategory.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie data={expenseByCategory} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} fill="#8884d8" label>
                    {expenseByCategory.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={(value: number) => formatCurrency(value)} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : <p className="text-center text-gray-500 py-12">No expense data for this period.</p>}
          </Card>

          <Card className="p-4">
            <h3 className="font-bold text-lg mb-4 text-center">Monthly Trends (Last 6 Months)</h3>
            {monthlyTrends.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={monthlyTrends}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis tickFormatter={(value: number) => `₹${value/1000}k`}/>
                  <Tooltip formatter={(value: number) => formatCurrency(value)} />
                  <Legend />
                  <Bar dataKey="income" fill="#22c55e" />
                  <Bar dataKey="expense" fill="#ef4444" />
                </BarChart>
              </ResponsiveContainer>
             ) : <p className="text-center text-gray-500 py-12">No transaction data available.</p>}
          </Card>
      </div>
    </div>
  );
};

export default AnalyserScreen;