import React, { useState, useMemo } from 'react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { useData } from '../../context/DataContext';
import { TransactionType, Transaction } from '../../types';
import TransactionList from '../TransactionList';
import Button from '../ui/Button';
import Modal from '../ui/Modal';
import TransactionForm from '../forms/TransactionForm';
import Card from '../ui/Card';

const PlusIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" x2="12" y1="5" y2="19"/><line x1="5" x2="19" y1="12" y2="12"/></svg>;
const DownloadIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>;

const AllExpensesScreen: React.FC = () => {
    const { transactions, sources, categories, deleteTransaction } = useData();
    const [isExpenseModalOpen, setExpenseModalOpen] = useState(false);
    const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
    const [transactionToDelete, setTransactionToDelete] = useState<{ id: string, transferId?: string } | null>(null);

    const [startDate, setStartDate] = useState(() => {
        const date = new Date();
        date.setDate(1); // First day of current month
        return date.toISOString().split('T')[0];
    });
    const [endDate, setEndDate] = useState(() => new Date().toISOString().split('T')[0]);

    const getSourceName = (id: string) => sources.find(s => s.id === id)?.name || 'Unknown';
    const getCategoryName = (id: string | undefined) => id ? (categories.find(c => c.id === id)?.name || 'Uncategorized') : 'Uncategorized';

    const expenseTransactions = useMemo(() => {
        if (!startDate || !endDate) return [];
        
        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);

        return transactions
            .filter(t => {
                if (t.type !== TransactionType.EXPENSE) return false;
                const tDate = new Date(t.date);
                return tDate >= start && tDate <= end;
            })
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [transactions, startDate, endDate]);

    const handleExportCSV = () => {
        if (expenseTransactions.length === 0) {
            alert("No expenses to export in the selected date range.");
            return;
        }

        const headers = ['Date', 'Description', 'Category', 'Source', 'Amount (INR)'];
        const rows = expenseTransactions.map(t => [
            `"${new Date(t.date).toLocaleString('en-IN')}"`,
            `"${t.description.replace(/"/g, '""')}"`,
            `"${getCategoryName(t.categoryId)}"`,
            `"${getSourceName(t.sourceId)}"`,
            t.amount
        ].join(','));

        const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows].join('\n');
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", `expenses-${startDate}-to-${endDate}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleExportPDF = () => {
        if (expenseTransactions.length === 0) {
            alert("No expenses to export in the selected date range.");
            return;
        }

        const doc = new jsPDF();
        const totalExpenses = expenseTransactions.reduce((sum, t) => sum + t.amount, 0);

        doc.setFontSize(18);
        doc.text("Expense Report", 14, 22);
        doc.setFontSize(11);
        doc.setTextColor(100);
        doc.text(`Date Range: ${startDate} to ${endDate}`, 14, 29);

        autoTable(doc, {
            startY: 35,
            head: [['Date', 'Description', 'Category', 'Source', 'Amount (INR)']],
            body: expenseTransactions.map(t => [
                new Date(t.date).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }),
                t.description,
                getCategoryName(t.categoryId),
                getSourceName(t.sourceId),
                { content: new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(t.amount), styles: { halign: 'right' } }
            ]),
            foot: [[
                { content: 'Total', colSpan: 4, styles: { halign: 'right', fontStyle: 'bold' } },
                { content: new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(totalExpenses), styles: { halign: 'right', fontStyle: 'bold' } }
            ]],
            headStyles: { fillColor: [37, 99, 235] }, // primary-600
            footStyles: { fillColor: [243, 244, 246] }, // gray-100
            didDrawPage: (data) => {
                doc.setFontSize(10);
                doc.text(`Page ${data.pageNumber}`, data.settings.margin.left, doc.internal.pageSize.height - 10);
            }
        });

        doc.save(`expenses-${startDate}-to-${endDate}.pdf`);
    };


    const handleDeleteRequest = (transactionId: string, transferId?: string) => {
        setTransactionToDelete({ id: transactionId, transferId });
    };

    const confirmDelete = () => {
        if (transactionToDelete) {
            deleteTransaction(transactionToDelete.id, transactionToDelete.transferId);
            setTransactionToDelete(null);
        }
    };

    const cancelDelete = () => {
        setTransactionToDelete(null);
    };
    
    const handleEdit = (transaction: Transaction) => {
        setEditingTransaction(transaction);
    };

    const handleCloseEditModal = () => {
      setEditingTransaction(null);
    }


    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white">All Expenses</h1>
                <Button onClick={() => setExpenseModalOpen(true)}>
                    <PlusIcon /> Add Expense
                </Button>
            </div>
            
            <Card className="p-6">
                <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200 mb-4">Export Expenses</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end">
                    <div>
                        <label htmlFor="start-date" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Start Date</label>
                        <input
                            id="start-date"
                            type="date"
                            value={startDate}
                            onChange={(e) => setStartDate(e.target.value)}
                            className="w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm p-2"
                        />
                    </div>
                    <div>
                        <label htmlFor="end-date" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">End Date</label>
                        <input
                            id="end-date"
                            type="date"
                            value={endDate}
                            onChange={(e) => setEndDate(e.target.value)}
                            className="w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm p-2"
                        />
                    </div>
                    <Button onClick={handleExportCSV} variant="secondary" className="w-full">
                        <DownloadIcon /> Export CSV (Excel)
                    </Button>
                    <Button onClick={handleExportPDF} variant="secondary" className="w-full">
                        <DownloadIcon /> Export PDF
                    </Button>
                </div>
            </Card>

            <TransactionList
                title="Filtered Expenses"
                transactions={expenseTransactions}
                showSource={true}
                onEdit={handleEdit}
                onDelete={handleDeleteRequest}
            />

            <Modal isOpen={isExpenseModalOpen} onClose={() => setExpenseModalOpen(false)} title="Add New Expense">
                <TransactionForm
                    type={TransactionType.EXPENSE}
                    sourceId={sources[0]?.id || ''}
                    onClose={() => setExpenseModalOpen(false)}
                />
            </Modal>

            {editingTransaction && (
              <Modal 
                  isOpen={!!editingTransaction} 
                  onClose={handleCloseEditModal} 
                  title="Edit Expense"
              >
                  <TransactionForm
                      type={TransactionType.EXPENSE}
                      sourceId={editingTransaction.sourceId}
                      onClose={handleCloseEditModal}
                      initialData={editingTransaction}
                  />
              </Modal>
            )}

            <Modal 
              isOpen={!!transactionToDelete} 
              onClose={cancelDelete} 
              title="Confirm Deletion"
            >
              <p className="text-gray-600 dark:text-gray-300 mb-6">Are you sure you want to delete this expense? This action cannot be undone.</p>
              <div className="flex justify-end gap-4">
                <Button variant="secondary" onClick={cancelDelete}>Cancel</Button>
                <Button variant="danger" onClick={confirmDelete}>Delete</Button>
              </div>
            </Modal>
        </div>
    );
};

export default AllExpensesScreen;