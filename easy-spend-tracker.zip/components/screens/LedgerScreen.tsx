import React, { useState, useMemo } from 'react';
import { useParams } from 'react-router-dom';
import { useData } from '../../context/DataContext';
import { TransactionType, Transaction } from '../../types';
import Card from '../ui/Card';
import Button from '../ui/Button';
import Modal from '../ui/Modal';
import TransactionList from '../TransactionList';
import TransactionForm from '../forms/TransactionForm';
import TransferForm from '../forms/TransferForm';

const PlusIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" x2="12" y1="5" y2="19"/><line x1="5" x2="19" y1="12" y2="12"/></svg>;
const ArrowRightLeftIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m16 3 4 4-4 4"/><path d="M20 7H4"/><path d="m8 21-4-4 4-4"/><path d="M4 17h16"/></svg>;

const LedgerScreen: React.FC = () => {
  const { sourceId } = useParams<{ sourceId: string }>();
  const { transactions, sources, getBalance, deleteTransaction } = useData();
  const [isIncomeModalOpen, setIncomeModalOpen] = useState(false);
  const [isTransferModalOpen, setTransferModalOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [transactionToDelete, setTransactionToDelete] = useState<{ id: string, transferId?: string } | null>(null);

  const source = useMemo(() => sources.find(s => s.id === sourceId), [sources, sourceId]);
  const sourceTransactions = useMemo(() => 
    transactions
      .filter(t => t.sourceId === sourceId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()),
    [transactions, sourceId]
  );
  
  const balance = source ? getBalance(source.id) : 0;
  const formatCurrency = (amount: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(amount);
  
  const handleDeleteRequest = (transactionId: string, transferId?: string) => {
    setTransactionToDelete({ id: transactionId, transferId });
  };
  
  const confirmDelete = () => {
    if (transactionToDelete) {
      deleteTransaction(transactionToDelete.id, transactionToDelete.transferId);
      setTransactionToDelete(null);
    }
  };

  const cancelDelete = () => {
    setTransactionToDelete(null);
  };

  const handleEdit = (transaction: Transaction) => {
    setEditingTransaction(transaction);
  };
  
  const handleCloseEditModal = () => {
    setEditingTransaction(null);
  }

  if (!source) {
    return <div>Source not found.</div>;
  }

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{source.name}</h2>
        <p className="text-lg text-gray-500 dark:text-gray-400">Current Balance</p>
        <p className="text-4xl font-bold text-primary-600 dark:text-primary-400 mt-2">{formatCurrency(balance)}</p>
      </Card>

      <div className="flex gap-4">
        <Button onClick={() => setIncomeModalOpen(true)} className="flex-1"><PlusIcon /> Add Income</Button>
        <Button onClick={() => setTransferModalOpen(true)} className="flex-1" variant="secondary"><ArrowRightLeftIcon/> Add Transfer</Button>
      </div>

      <TransactionList 
        transactions={sourceTransactions}
        onEdit={handleEdit}
        onDelete={handleDeleteRequest}
      />

      <Modal isOpen={isIncomeModalOpen} onClose={() => setIncomeModalOpen(false)} title={`Add Income to ${source.name}`}>
        <TransactionForm type={TransactionType.INCOME} sourceId={source.id} onClose={() => setIncomeModalOpen(false)} />
      </Modal>

      <Modal isOpen={isTransferModalOpen} onClose={() => setTransferModalOpen(false)} title="Transfer Funds">
        <TransferForm onClose={() => setTransferModalOpen(false)} fromSourceId={source.id}/>
      </Modal>

      {editingTransaction && (
        <Modal 
            isOpen={!!editingTransaction} 
            onClose={handleCloseEditModal} 
            title={`Edit Transaction`}
        >
            <TransactionForm
                type={editingTransaction.type as (TransactionType.INCOME | TransactionType.EXPENSE)}
                sourceId={editingTransaction.sourceId}
                onClose={handleCloseEditModal}
                initialData={editingTransaction}
            />
        </Modal>
      )}

      <Modal 
        isOpen={!!transactionToDelete} 
        onClose={cancelDelete} 
        title="Confirm Deletion"
      >
        <p className="text-gray-600 dark:text-gray-300 mb-6">Are you sure you want to delete this transaction? This action cannot be undone.</p>
        <div className="flex justify-end gap-4">
          <Button variant="secondary" onClick={cancelDelete}>Cancel</Button>
          <Button variant="danger" onClick={confirmDelete}>Delete</Button>
        </div>
      </Modal>
    </div>
  );
};

export default LedgerScreen;