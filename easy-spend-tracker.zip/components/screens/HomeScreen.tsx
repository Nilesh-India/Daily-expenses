
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { useData } from '../../context/DataContext';
import { TransactionType, type Source, Transaction } from '../../types';
import Card from '../ui/Card';
import Button from '../ui/Button';
import Modal from '../ui/Modal';

const LandmarkIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" x2="21" y1="22" y2="22"/><line x1="6" x2="6" y1="18" y2="11"/><line x1="10" x2="10" y1="18" y2="11"/><line x1="14" x2="14" y1="18" y2="11"/><line x1="18" x2="18" y1="18" y2="11"/><polygon points="12 2 2 7 12 12 22 7 12 2"/></svg>;
const WalletIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/></svg>;
const CircleDollarSignIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"/><path d="M12 18V6"/></svg>;
const ChartPieIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/></svg>;
const DownloadCloudIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 12v9"/><path d="m16 16-4 4-4-4"/><path d="M20 12v-2a4 4 0 0 0-2.2-3.7"/><path d="M12 2a5 5 0 0 0-5 5v1.5a2.5 2.5 0 0 1-5 0V7a5 5 0 0 1 5-5"/><path d="M12 2a5 5 0 0 1 5 5v1.5a2.5 2.5 0 0 0 5 0V7a5 5 0 0 0-5-5"/></svg>;
const ListMinus = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 12H3"/><path d="M16 6H3"/><path d="M16 18H3"/><path d="M21 12h-6"/></svg>
const PencilIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>;
const TrashIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>;
const HelpCircleIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>;
const DocumentTextIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><line x1="10" y1="9" x2="8" y2="9"/></svg>;


const ICONS: { [key: string]: React.ReactNode } = {
  landmark: <LandmarkIcon />,
  wallet: <WalletIcon />,
  'circle-dollar-sign': <CircleDollarSignIcon />,
};

const HomeScreen: React.FC = () => {
  const navigate = useNavigate();
  const { sources, getBalance, transactions, addSource, updateSource, deleteSource, categories } = useData();
  const [isManageModalOpen, setManageModalOpen] = useState(false);
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [editedSources, setEditedSources] = useState<Source[]>([]);
  const [newAccountName, setNewAccountName] = useState('');
  const [newAccountIcon, setNewAccountIcon] = useState('landmark');

  const [startDate, setStartDate] = useState(() => {
    const date = new Date();
    date.setDate(1);
    return date.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(() => new Date().toISOString().split('T')[0]);

  const totalBalance = sources.reduce((sum, source) => sum + getBalance(source.id), 0);
  
  const monthlySummaries = useMemo(() => {
    const now = new Date();
    const dates = [
        now,
        new Date(now.getFullYear(), now.getMonth() - 1, 1),
        new Date(now.getFullYear(), now.getMonth() - 2, 1)
    ];

    return dates.map(date => {
        const year = date.getFullYear();
        const month = date.getMonth();
        const monthName = date.toLocaleString('default', { month: 'long' });

        const income = transactions
            .filter(t => {
                const tDate = new Date(t.date);
                return (t.type === TransactionType.INCOME || (t.type === TransactionType.TRANSFER && t.description.includes('from'))) &&
                        tDate.getMonth() === month &&
                        tDate.getFullYear() === year;
            })
            .reduce((sum, t) => sum + t.amount, 0);

        const expense = transactions
            .filter(t => {
                const tDate = new Date(t.date);
                return (t.type === TransactionType.EXPENSE || (t.type === TransactionType.TRANSFER && t.description.includes('to'))) &&
                        tDate.getMonth() === month &&
                        tDate.getFullYear() === year;
            })
            .reduce((sum, t) => sum + t.amount, 0);

        return { monthName, income, expense };
    });
  }, [transactions]);

  const formatCurrency = (amount: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(amount);

  useEffect(() => {
    if (isManageModalOpen) {
      setEditedSources(sources);
    }
  }, [isManageModalOpen, sources]);

  const handleSourceNameChange = (id: string, name: string) => {
    setEditedSources(prev => prev.map(s => (s.id === id ? { ...s, name } : s)));
  };

  const handleSaveChanges = () => {
    editedSources.forEach(editedSource => {
      const originalSource = sources.find(s => s.id === editedSource.id);
      if (originalSource && originalSource.name !== editedSource.name) {
        updateSource(editedSource.id, editedSource.name);
      }
    });
    setManageModalOpen(false);
  };
  
  const handleDeleteSource = (id: string) => {
    const sourceToDelete = sources.find(s => s.id === id);
    if (!sourceToDelete) return;

    if (window.confirm(`Are you sure you want to delete "${sourceToDelete.name}"? This will also delete all its transactions.`)) {
      deleteSource(id);
    }
  };

  const handleAddAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (newAccountName.trim()) {
      addSource(newAccountName.trim(), newAccountIcon);
      setNewAccountName('');
      setNewAccountIcon('landmark');
    }
  };

  const getSourceName = (id: string) => sources.find(s => s.id === id)?.name || 'Unknown';
  const getCategoryName = (id: string | undefined) => id ? (categories.find(c => c.id === id)?.name || 'Uncategorized') : 'N/A';

  const filteredTransactionsForExport = useMemo(() => {
    if (!startDate || !endDate) return [];
    
    const start = new Date(startDate);
    start.setHours(0, 0, 0, 0);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);

    return transactions
      .filter(t => {
          const tDate = new Date(t.date);
          return tDate >= start && tDate <= end;
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [transactions, startDate, endDate]);

  const getTransactionTypeForExport = (t: Transaction): string => {
      const isIncome = t.type === TransactionType.INCOME || (t.type === TransactionType.TRANSFER && t.description.includes('from'));
      if (t.type === TransactionType.TRANSFER) {
          return isIncome ? 'Transfer In' : 'Transfer Out';
      }
      return t.type.charAt(0).toUpperCase() + t.type.slice(1).toLowerCase();
  };
  
  const handleExportCSV = () => {
    if (filteredTransactionsForExport.length === 0) {
        alert("No transactions to export in the selected date range.");
        return;
    }

    const headers = ['Date', 'Description', 'Type', 'Category', 'Source', 'Amount (INR)'];
    const rows = filteredTransactionsForExport.map(t => [
        `"${new Date(t.date).toLocaleString('en-IN')}"`,
        `"${t.description.replace(/"/g, '""')}"`,
        `"${getTransactionTypeForExport(t)}"`,
        `"${getCategoryName(t.categoryId)}"`,
        `"${getSourceName(t.sourceId)}"`,
        t.amount
    ].join(','));

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `transactions-${startDate}-to-${endDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportPDF = () => {
    if (filteredTransactionsForExport.length === 0) {
        alert("No transactions to export in the selected date range.");
        return;
    }

    const doc = new jsPDF();
    const isIncomeTx = (t: Transaction) => t.type === TransactionType.INCOME || (t.type === TransactionType.TRANSFER && t.description.includes('from'));

    const totalIncome = filteredTransactionsForExport.filter(isIncomeTx).reduce((sum, t) => sum + t.amount, 0);
    const totalExpense = filteredTransactionsForExport.filter(t => !isIncomeTx(t)).reduce((sum, t) => sum + t.amount, 0);

    doc.setFontSize(18);
    doc.text("Transaction Report", 14, 22);
    doc.setFontSize(11);
    doc.setTextColor(100);
    doc.text(`Date Range: ${new Date(startDate).toLocaleDateString('en-IN')} to ${new Date(endDate).toLocaleDateString('en-IN')}`, 14, 29);

    autoTable(doc, {
        startY: 35,
        head: [['Date', 'Description', 'Type', 'Category', 'Source', 'Amount']],
        body: filteredTransactionsForExport.map(t => [
            new Date(t.date).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }),
            t.description,
            getTransactionTypeForExport(t),
            getCategoryName(t.categoryId),
            getSourceName(t.sourceId),
            { content: formatCurrency(t.amount), styles: { halign: 'right' } }
        ]),
        foot: [
            [{ content: 'Total Income', colSpan: 5, styles: { halign: 'right', fontStyle: 'bold' } }, { content: formatCurrency(totalIncome), styles: { halign: 'right', fontStyle: 'bold', textColor: [34, 197, 94] } }],
            [{ content: 'Total Expense', colSpan: 5, styles: { halign: 'right', fontStyle: 'bold' } }, { content: formatCurrency(totalExpense), styles: { halign: 'right', fontStyle: 'bold', textColor: [239, 68, 68] } }],
            [{ content: 'Net Savings', colSpan: 5, styles: { halign: 'right', fontStyle: 'bold' } }, { content: formatCurrency(totalIncome - totalExpense), styles: { halign: 'right', fontStyle: 'bold' } }]
        ],
        headStyles: { fillColor: [37, 99, 235] },
        footStyles: { fillColor: [243, 244, 246], textColor: [17, 24, 39] },
        didDrawPage: (data) => {
            doc.setFontSize(10);
            doc.text(`Page ${data.pageNumber}`, data.settings.margin.left, doc.internal.pageSize.height - 10);
        }
    });

    doc.save(`transactions-${startDate}-to-${endDate}.pdf`);
  };

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <div className="text-center">
            <h2 className="text-lg font-medium text-gray-500 dark:text-gray-400">Total Balance</h2>
            <p className="text-4xl font-bold text-gray-900 dark:text-white mt-1">{formatCurrency(totalBalance)}</p>
        </div>
        <div className="mt-6 border-t border-gray-200 dark:border-gray-700 pt-4">
            <h3 className="text-md font-semibold text-center text-gray-600 dark:text-gray-300 mb-4">Monthly Summary</h3>
            <div className="grid grid-cols-3 gap-4 text-center">
                {monthlySummaries.map(({ monthName, income, expense }, index) => (
                    <div key={index}>
                        <p className="text-sm sm:text-base font-bold text-gray-800 dark:text-gray-200 truncate">{monthName}</p>
                        <div className="mt-2">
                            <p className="text-xs text-gray-500 dark:text-gray-400">Income</p>
                            <p className="text-sm sm:text-base font-semibold text-income">{formatCurrency(income)}</p>
                        </div>
                        <div className="mt-1">
                            <p className="text-xs text-gray-500 dark:text-gray-400">Expense</p>
                            <p className="text-sm sm:text-base font-semibold text-expense">{formatCurrency(expense)}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      </Card>
      
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200">Accounts</h2>
          <Button variant="secondary" onClick={() => setManageModalOpen(true)} className="!py-1.5 !px-3 text-sm">
            <PencilIcon />
            <span className="hidden sm:inline ml-2">Manage</span>
          </Button>
        </div>
        <div className="space-y-3">
          {sources.map(source => (
            <Card key={source.id} className="p-4 flex items-center justify-between cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200" onClick={() => navigate(`/source/${source.id}`)}>
              <div className="flex items-center gap-4">
                <span className="text-primary-500">{ICONS[source.icon] || <CircleDollarSignIcon />}</span>
                <span className="font-semibold text-lg">{source.name}</span>
              </div>
              <span className="font-bold text-lg">{formatCurrency(getBalance(source.id))}</span>
            </Card>
          ))}
        </div>
      </div>
      
      <div>
        <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200 mb-4">Actions</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            <Button className="w-full h-16 text-md sm:text-lg" variant="secondary" onClick={() => navigate('/expenses')}><ListMinus/> All Expenses</Button>
            <Button className="w-full h-16 text-md sm:text-lg" variant="secondary" onClick={() => navigate('/analyser')}><ChartPieIcon/> Analyser</Button>
            <Button className="w-full h-16 text-md sm:text-lg" variant="secondary" onClick={() => setExportModalOpen(true)}><DocumentTextIcon/> Export Data</Button>
            <Button className="w-full h-16 text-md sm:text-lg" variant="secondary" onClick={() => navigate('/backup')}><DownloadCloudIcon/> Backup</Button>
            <Button className="w-full h-16 text-md sm:text-lg" variant="secondary" onClick={() => navigate('/guide')}><HelpCircleIcon/> App Guide</Button>
        </div>
      </div>

      <Modal isOpen={isManageModalOpen} onClose={() => setManageModalOpen(false)} title="Manage Accounts">
        <div className="space-y-6">
            <div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Edit Accounts</h3>
                <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                    {editedSources.map(source => (
                        <div key={source.id} className="flex items-center gap-2">
                            <input
                                type="text"
                                value={source.name}
                                onChange={(e) => handleSourceNameChange(source.id, e.target.value)}
                                className="flex-grow bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm p-2"
                            />
                            <Button variant="danger" onClick={() => handleDeleteSource(source.id)} className="!p-2.5 flex-shrink-0">
                               <TrashIcon />
                            </Button>
                        </div>
                    ))}
                </div>
            </div>

            <hr className="border-gray-200 dark:border-gray-600" />
            
            <div>
                 <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Add New Account</h3>
                 <form onSubmit={handleAddAccount} className="space-y-3">
                     <input
                        type="text"
                        value={newAccountName}
                        onChange={(e) => setNewAccountName(e.target.value)}
                        placeholder="New account name"
                        className="w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm p-2"
                        required
                    />
                    <div className="flex items-center gap-4">
                        <select
                            id="icon-select"
                            value={newAccountIcon}
                            onChange={(e) => setNewAccountIcon(e.target.value)}
                            className="flex-grow bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm p-2"
                        >
                            <option value="landmark">Bank</option>
                            <option value="wallet">Wallet</option>
                            <option value="circle-dollar-sign">Other</option>
                        </select>
                        <Button type="submit" className="w-full sm:w-auto">Add Account</Button>
                    </div>
                 </form>
            </div>
            
            <div className="flex justify-end pt-4 border-t border-gray-200 dark:border-gray-700">
                <Button onClick={handleSaveChanges}>Save & Close</Button>
            </div>
        </div>
    </Modal>
    <Modal isOpen={isExportModalOpen} onClose={() => setExportModalOpen(false)} title="Export Transactions">
        <div className="space-y-4">
            <p className="text-gray-600 dark:text-gray-300">Select a date range and format to export your transaction data.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end">
                <div>
                    <label htmlFor="start-date-export" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Start Date</label>
                    <input
                        id="start-date-export"
                        type="date"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                        className="w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm p-2"
                    />
                </div>
                <div>
                    <label htmlFor="end-date-export" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">End Date</label>
                    <input
                        id="end-date-export"
                        type="date"
                        value={endDate}
                        onChange={(e) => setEndDate(e.target.value)}
                        className="w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm p-2"
                    />
                </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                <Button onClick={handleExportCSV} variant="secondary" className="w-full">
                    Export CSV (for Excel)
                </Button>
                <Button onClick={handleExportPDF} variant="secondary" className="w-full">
                    Export PDF
                </Button>
            </div>
        </div>
    </Modal>
    </div>
  );
};

export default HomeScreen;
