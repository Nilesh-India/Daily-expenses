
import React, { useRef, useState } from 'react';
import { useData } from '../../context/DataContext';
import Card from '../ui/Card';
import Button from '../ui/Button';

const DownloadIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>;
const UploadIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/></svg>;

const BackupScreen: React.FC = () => {
    const { getAllData, restoreData } = useData();
    const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleBackup = () => {
        try {
            const data = getAllData();
            const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(JSON.stringify(data, null, 2))}`;
            const link = document.createElement('a');
            link.href = jsonString;
            const date = new Date().toISOString().split('T')[0];
            link.download = `easy-spend-tracker-backup-${date}.json`;
            link.click();
            setMessage({ text: 'Backup downloaded successfully!', type: 'success' });
        } catch (error) {
            setMessage({ text: 'Failed to create backup.', type: 'error' });
            console.error(error);
        }
    };

    const handleRestore = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const text = e.target?.result;
                if (typeof text !== 'string') {
                     setMessage({ text: 'Failed to read file.', type: 'error' });
                    return;
                }
                const parsedData = JSON.parse(text);
                if (restoreData(parsedData)) {
                    setMessage({ text: 'Data restored successfully! The app will now use the restored data.', type: 'success' });
                } else {
                    setMessage({ text: 'Invalid backup file format.', type: 'error' });
                }
            } catch (error) {
                setMessage({ text: 'Failed to parse backup file. Make sure it is a valid JSON file from this app.', type: 'error' });
                console.error(error);
            }
        };
        reader.readAsText(file);
    };

    const triggerFileSelect = () => fileInputRef.current?.click();

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Backup & Restore</h1>
            <Card className="p-6">
                <div className="space-y-4">
                    <p className="text-gray-600 dark:text-gray-300">
                        Backup your data to a local JSON file. You can use this file to restore your data on any device.
                        <br/>
                        <strong className="text-red-500">Warning:</strong> Restoring will overwrite all current data in the app.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4">
                        <Button onClick={handleBackup} className="w-full sm:w-auto"><DownloadIcon/> Manual Backup</Button>
                        <Button onClick={triggerFileSelect} variant="secondary" className="w-full sm:w-auto"><UploadIcon /> Restore from Backup</Button>
                        <input
                            type="file"
                            ref={fileInputRef}
                            onChange={handleRestore}
                            className="hidden"
                            accept=".json"
                        />
                    </div>
                    {message && (
                        <div className={`mt-4 p-3 rounded-lg text-sm ${message.type === 'success' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'}`}>
                            {message.text}
                        </div>
                    )}
                </div>
            </Card>
             <Card className="p-6">
                <h2 className="text-xl font-bold mb-2">Backing Up to Google Drive</h2>
                <div className="text-gray-600 dark:text-gray-300 space-y-3">
                    <p>
                        This app runs completely offline, meaning your data is stored only on your device. To keep your data safe, you should manually back it up to a cloud service like Google Drive.
                    </p>
                    <h3 className="font-semibold text-gray-800 dark:text-gray-100">Here are the steps to back up your data:</h3>
                    <ol className="list-decimal list-inside space-y-2 pl-2">
                        <li>Click the <strong className="font-semibold text-primary-600 dark:text-primary-400">Manual Backup</strong> button above to download the backup file (a `.json` file) to your device.</li>
                        <li>Open your Google Drive app or visit <a href="https://drive.google.com" target="_blank" rel="noopener noreferrer" className="text-primary-500 hover:underline">drive.google.com</a> in your browser.</li>
                        <li>Upload the downloaded backup file to your Google Drive.</li>
                        <li>To restore, you will first need to download the backup file from Google Drive back to your device, then use the <strong className="font-semibold text-primary-600 dark:text-primary-400">Restore from Backup</strong> feature in this app.</li>
                    </ol>
                </div>
            </Card>
        </div>
    );
};

export default BackupScreen;
