import React from 'react';
import Card from '../ui/Card';

const TermsScreen: React.FC = () => {
    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Terms & Conditions</h1>
            <Card className="p-6">
                <div className="prose prose-lg dark:prose-invert max-w-none text-gray-700 dark:text-gray-300">
                    <p>Last updated: {new Date().toLocaleDateString()}</p>

                    <p>Please read these Terms and Conditions ("Terms", "Terms and Conditions") carefully before using the Easy Spend Tracker application (the "Service") operated by the developer ("us", "we", or "our").</p>
                    
                    <p>Your access to and use of the Service is conditioned on your acceptance of and compliance with these Terms. These Terms apply to all visitors, users, and others who access or use the Service.</p>
                    
                    <h2 className="text-xl font-bold mt-6 mb-2 text-gray-900 dark:text-white">1. Description of Service</h2>
                    <p>Easy Spend Tracker is an offline-first application designed to help you track your income and expenses. All data you enter is stored exclusively on your local device's browser storage. The Service does not transmit or store your personal financial data on any external servers.</p>

                    <h2 className="text-xl font-bold mt-6 mb-2 text-gray-900 dark:text-white">2. User Responsibilities</h2>
                    <p>You are solely responsible for the accuracy of the financial data you enter into the application. You are also solely responsible for backing up your data using the "Backup / Restore" functionality. Since the data is stored locally, clearing your browser cache, using a private/incognito window, or switching devices will result in data loss unless you have created a backup.</p>

                    <h2 className="text-xl font-bold mt-6 mb-2 text-gray-900 dark:text-white">3. Disclaimer of Warranties and Limitation of Liability</h2>
                    <p><strong>This is a critical section. Please read it carefully.</strong></p>
                    
                    <p>The Service is provided on an "AS IS" and "AS AVAILABLE" basis. The use of the Service is at your own risk. To the maximum extent permitted by applicable law, the Service is provided without warranties of any kind, whether express or implied, including, but not limited to, implied warranties of merchantability, fitness for a particular purpose, or non-infringement.</p>
                    
                    <p>In no event shall the developer, its affiliates, agents, directors, or employees, be liable for any direct, indirect, punitive, incidental, special, consequential or exemplary damages, including without limitation damages for loss of profits, goodwill, use, data or other intangible losses, that result from the use of, or inability to use, this Service.</p>
                    
                    <p>We do not warrant that the Service will be available at any particular time or location, uninterrupted or secure; that any defects or errors will be corrected; or that the Service is free of viruses or other harmful components. You are responsible for taking your own precautions to protect your device and data.</p>
                    
                    <p><strong>By using this application, you acknowledge and agree that the developer is not and will not be held responsible for any loss of data, financial or otherwise, that may occur for any reason, including but not limited to software bugs, device failure, user error, or any other cause.</strong></p>
                    
                    <h2 className="text-xl font-bold mt-6 mb-2 text-gray-900 dark:text-white">4. Changes to Terms</h2>
                    <p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. We will try to provide notice of any changes by updating the "Last updated" date of these Terms. What constitutes a material change will be determined at our sole discretion.</p>

                    <h2 className="text-xl font-bold mt-6 mb-2 text-gray-900 dark:text-white">5. Contact Us</h2>
                    <p>If you have any questions about these Terms, please understand that this is a free, unsupported application. We provide no official channel for support.</p>
                </div>
            </Card>
        </div>
    );
};

export default TermsScreen;
