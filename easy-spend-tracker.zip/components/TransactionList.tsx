import React from 'react';
import type { Transaction, Source, Category } from '../types';
import { TransactionType } from '../types';
import { useData } from '../context/DataContext';

const PencilIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>;
const TrashIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>;

interface TransactionListProps {
  transactions: Transaction[];
  title?: string;
  showSource?: boolean;
  onEdit?: (transaction: Transaction) => void;
  onDelete?: (transactionId: string, transferId?: string) => void;
}

const TransactionList: React.FC<TransactionListProps> = ({ transactions, title, showSource = false, onEdit, onDelete }) => {
  const { sources, categories } = useData();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(amount);
  };
  
  const getSourceName = (id: string) => sources.find(s => s.id === id)?.name || 'Unknown';
  const getCategoryName = (id: string) => categories.find(c => c.id === id)?.name || 'Uncategorized';
  
  if (transactions.length === 0) {
    return (
      <div className="text-center py-10 text-gray-500 dark:text-gray-400">
        <p>No transactions yet.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {title && <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200">{title}</h2>}
      <ul className="space-y-3">
        {transactions.map(t => {
          const isIncome = t.type === TransactionType.INCOME || (t.type === TransactionType.TRANSFER && t.description.includes('from'));
          const amountColor = isIncome ? 'text-income' : 'text-expense';
          const isTransfer = t.type === TransactionType.TRANSFER;

          return (
            <li key={t.id} className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm flex items-center justify-between gap-2">
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-gray-900 dark:text-white truncate">{t.description}</p>
                <div className="text-sm text-gray-500 dark:text-gray-400 flex items-center gap-2 flex-wrap">
                  <span>{new Date(t.date).toLocaleString('en-IN')}</span>
                  {t.categoryId && <span>&bull; {getCategoryName(t.categoryId)}</span>}
                  {showSource && <span>&bull; {getSourceName(t.sourceId)}</span>}
                </div>
              </div>
              <div className="flex items-center gap-3 flex-shrink-0">
                <p className={`font-bold text-lg ${amountColor} text-right`}>
                  {isIncome ? '+' : '-'} {formatCurrency(t.amount)}
                </p>
                {(onEdit || onDelete) && (
                  <div className="flex items-center gap-1">
                    {onEdit && !isTransfer && (
                      <button onClick={() => onEdit(t)} className="p-2 rounded-full text-gray-400 hover:text-primary-500 hover:bg-gray-100 dark:hover:bg-gray-700">
                        <PencilIcon />
                      </button>
                    )}
                    {onDelete && (
                       <button onClick={() => onDelete(t.id, t.transferId)} className="p-2 rounded-full text-gray-400 hover:text-red-500 hover:bg-gray-100 dark:hover:bg-gray-700">
                        <TrashIcon />
                      </button>
                    )}
                  </div>
                )}
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default TransactionList;