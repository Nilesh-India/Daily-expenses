import React, { useState, useEffect } from 'react';
import { useData } from '../../context/DataContext';
import { TransactionType, Transaction } from '../../types';
import Button from '../ui/Button';
import Modal from '../ui/Modal';

interface TransactionFormProps {
  type: TransactionType.INCOME | TransactionType.EXPENSE;
  sourceId: string; // Used as default for new transactions
  onClose: () => void;
  initialData?: Transaction; // For editing
}

// Helper to format a Date object into a string for datetime-local input
const getLocalDateTimeForInput = (dateObj: Date): string => {
    const year = dateObj.getFullYear();
    const month = (dateObj.getMonth() + 1).toString().padStart(2, '0');
    const day = dateObj.getDate().toString().padStart(2, '0');
    const hours = dateObj.getHours().toString().padStart(2, '0');
    const minutes = dateObj.getMinutes().toString().padStart(2, '0');
    return `${year}-${month}-${day}T${hours}:${minutes}`;
};


const TransactionForm: React.FC<TransactionFormProps> = ({ type, sourceId, onClose, initialData }) => {
  const { addIncome, addExpense, categories, sources, updateTransaction, getBalance } = useData();
  
  const isEditMode = !!initialData;
  const isExpense = isEditMode ? initialData.type === TransactionType.EXPENSE : type === TransactionType.EXPENSE;

  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(getLocalDateTimeForInput(new Date()));
  const [categoryId, setCategoryId] = useState('');
  const [currentSourceId, setCurrentSourceId] = useState(sourceId);
  const [errorModalOpen, setErrorModalOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  
  useEffect(() => {
    if (initialData) {
      setAmount(initialData.amount.toString());
      setDescription(initialData.description);
      setDate(getLocalDateTimeForInput(new Date(initialData.date)));
      setCategoryId(initialData.categoryId || '');
      setCurrentSourceId(initialData.sourceId);
    }
  }, [initialData]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0 || !description) return;
    
    if (!isEditMode && isExpense) {
        const balance = getBalance(currentSourceId);
        const sourceName = sources.find(s => s.id === currentSourceId)?.name || 'the account';
        if (numericAmount > balance) {
            setErrorMessage(`Insufficient balance in ${sourceName}. Your current balance is ${new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(balance)}, but the expense is ${new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(numericAmount)}.`);
            setErrorModalOpen(true);
            return;
        }
    }
    
    const transactionDate = new Date(date).toISOString();

    if (isEditMode && initialData) {
      const transactionData = {
        amount: numericAmount,
        description,
        date: transactionDate,
        categoryId: isExpense ? categoryId : undefined,
      };
      updateTransaction(initialData.id, transactionData);
    } else {
      const transactionData = {
        sourceId: isExpense ? currentSourceId : sourceId,
        amount: numericAmount,
        description,
        date: transactionDate,
        categoryId: isExpense ? categoryId : undefined,
      };

      if (isExpense) {
        addExpense(transactionData);
      } else {
        addIncome(transactionData);
      }
    }
    onClose();
  };

  return (
    <>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="amount" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Amount (₹)</label>
          <input
            id="amount" type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)}
            className="mt-1 block w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm p-2"
            placeholder="0.00" required
          />
        </div>
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Source of {isExpense ? 'Expense' : 'Income'}</label>
          <input
            id="description" type="text" value={description} onChange={(e) => setDescription(e.target.value)}
            className="mt-1 block w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm p-2"
            placeholder={isExpense ? 'e.g., Lunch' : 'e.g., Salary'} required
          />
        </div>
        {isExpense && (
          <>
            <div>
              <label htmlFor="category" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Category</label>
              <select
                id="category" value={categoryId} onChange={(e) => setCategoryId(e.target.value)}
                className="mt-1 block w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm p-2" required
              >
                {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            {!isEditMode && (
              <div>
                <label htmlFor="source" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Paid from</label>
                <select
                  id="source" value={currentSourceId} onChange={(e) => setCurrentSourceId(e.target.value)}
                  className="mt-1 block w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm p-2" required
                >
                  {sources.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
            )}
          </>
        )}
        <div>
          <label htmlFor="date" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Date & Time</label>
          <input
            id="date" type="datetime-local" value={date} onChange={(e) => setDate(e.target.value)}
            className="mt-1 block w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm p-2" required
          />
        </div>
        <div className="flex justify-end pt-4">
          <Button type="submit">{isEditMode ? 'Save Changes' : `Add ${isExpense ? 'Expense' : 'Income'}`}</Button>
        </div>
      </form>
      <Modal
        isOpen={errorModalOpen}
        onClose={() => setErrorModalOpen(false)}
        title="Transaction Error"
      >
        <p className="text-gray-600 dark:text-gray-300 mb-4">{errorMessage}</p>
        <div className="flex justify-end">
          <Button onClick={() => setErrorModalOpen(false)}>OK</Button>
        </div>
      </Modal>
    </>
  );
};

export default TransactionForm;