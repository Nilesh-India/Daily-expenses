import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import Button from '../ui/Button';
import Modal from '../ui/Modal';

interface TransferFormProps {
  onClose: () => void;
  fromSourceId?: string;
}

// Helper to format a Date object into a string for datetime-local input
const getLocalDateTimeForInput = (dateObj: Date): string => {
    const year = dateObj.getFullYear();
    const month = (dateObj.getMonth() + 1).toString().padStart(2, '0');
    const day = dateObj.getDate().toString().padStart(2, '0');
    const hours = dateObj.getHours().toString().padStart(2, '0');
    const minutes = dateObj.getMinutes().toString().padStart(2, '0');
    return `${year}-${month}-${day}T${hours}:${minutes}`;
};

const TransferForm: React.FC<TransferFormProps> = ({ onClose, fromSourceId }) => {
  const { addTransfer, sources, getBalance } = useData();
  const [from, setFrom] = useState(fromSourceId || sources[0]?.id || '');
  const [to, setTo] = useState(sources.filter(s => s.id !== (fromSourceId || sources[0]?.id))[0]?.id || '');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(getLocalDateTimeForInput(new Date()));
  const [isErrorModalOpen, setErrorModalOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
        setErrorMessage("Please enter a valid amount for the transfer.");
        setErrorModalOpen(true);
        return;
    }
     if (from === to) {
        setErrorMessage("The 'From' and 'To' accounts cannot be the same. Please select a different account to transfer to.");
        setErrorModalOpen(true);
        return;
    }

    const fromSourceBalance = getBalance(from);
    if (numericAmount > fromSourceBalance) {
        const fromSourceName = sources.find(s => s.id === from)?.name || 'the account';
        setErrorMessage(`Insufficient balance in ${fromSourceName}. Your current balance is ${new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(fromSourceBalance)}, but the transfer amount is ${new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(numericAmount)}.`);
        setErrorModalOpen(true);
        return;
    }

    const transactionDate = new Date(date).toISOString();
    addTransfer(from, to, numericAmount, transactionDate);
    onClose();
  };

  const availableToSources = sources.filter(s => s.id !== from);

  return (
    <>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="amount" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Amount (₹)</label>
          <input
            id="amount" type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)}
            className="mt-1 block w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm p-2"
            placeholder="0.00" required
          />
        </div>
        <div>
          <label htmlFor="from" className="block text-sm font-medium text-gray-700 dark:text-gray-300">From</label>
          <select
            id="from" value={from} onChange={(e) => setFrom(e.target.value)}
            className="mt-1 block w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm p-2" required
          >
            {sources.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </div>
         <div>
          <label htmlFor="to" className="block text-sm font-medium text-gray-700 dark:text-gray-300">To</label>
          <select
            id="to" value={to} onChange={(e) => setTo(e.target.value)}
            className="mt-1 block w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm p-2" required
          >
            {availableToSources.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="date" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Date & Time</label>
          <input
            id="date" type="datetime-local" value={date} onChange={(e) => setDate(e.target.value)}
            className="mt-1 block w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm p-2" required
          />
        </div>
        <div className="flex justify-end pt-4">
          <Button type="submit">Transfer Funds</Button>
        </div>
      </form>
      <Modal
        isOpen={isErrorModalOpen}
        onClose={() => setErrorModalOpen(false)}
        title="Transfer Error"
      >
        <p className="text-gray-600 dark:text-gray-300 mb-4">{errorMessage}</p>
        <div className="flex justify-end">
          <Button onClick={() => setErrorModalOpen(false)}>OK</Button>
        </div>
      </Modal>
    </>
  );
};

export default TransferForm;