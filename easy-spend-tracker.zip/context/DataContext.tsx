import React, { createContext, useContext, useMemo } from 'react';
import type { ReactNode } from 'react';
import { v4 as uuidv4 } from 'uuid';
import useLocalStorage from '../hooks/useLocalStorage';
import type { Transaction, Source, Category } from '../types';
import { TransactionType } from '../types';
import { INITIAL_SOURCES, INITIAL_CATEGORIES } from '../constants';

interface DataContextType {
  transactions: Transaction[];
  sources: Source[];
  categories: Category[];
  addIncome: (data: Omit<Transaction, 'id' | 'type'>) => void;
  addExpense: (data: Omit<Transaction, 'id' | 'type'>) => void;
  addTransfer: (fromSourceId: string, toSourceId: string, amount: number, date: string, notes?: string) => void;
  getBalance: (sourceId: string) => number;
  getAllData: () => { transactions: Transaction[], sources: Source[], categories: Category[] };
  restoreData: (data: { transactions: Transaction[], sources: Source[], categories: Category[] }) => boolean;
  addSource: (name: string, icon: string) => void;
  updateSource: (id: string, name: string) => void;
  deleteSource: (id: string) => void;
  updateTransaction: (id: string, data: Partial<Omit<Transaction, 'id' | 'type' | 'transferId'>>) => void;
  deleteTransaction: (id: string, transferId?: string) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [transactions, setTransactions] = useLocalStorage<Transaction[]>('transactions', []);
  const [sources, setSources] = useLocalStorage<Source[]>('sources', INITIAL_SOURCES);
  const [categories, setCategories] = useLocalStorage<Category[]>('categories', INITIAL_CATEGORIES);

  const addTransaction = (transaction: Omit<Transaction, 'id'>) => {
    const newTransaction: Transaction = { ...transaction, id: uuidv4() };
    setTransactions(prev => [...prev, newTransaction]);
  };

  const addIncome = (data: Omit<Transaction, 'id' | 'type'>) => {
    addTransaction({ ...data, type: TransactionType.INCOME });
  };
  
  const addExpense = (data: Omit<Transaction, 'id' | 'type'>) => {
    addTransaction({ ...data, type: TransactionType.EXPENSE });
  };

  const addTransfer = (fromSourceId: string, toSourceId: string, amount: number, date: string, notes?: string) => {
    const transferId = uuidv4();
    const fromSource = sources.find(s => s.id === fromSourceId);
    const toSource = sources.find(s => s.id === toSourceId);

    if(!fromSource || !toSource) return;

    // Expense from source
    addTransaction({
      type: TransactionType.TRANSFER,
      sourceId: fromSourceId,
      amount: amount,
      description: `Transfer to ${toSource.name}`,
      date: date,
      notes: notes,
      transferId: transferId,
    });

    // Income to destination
    addTransaction({
      type: TransactionType.TRANSFER,
      sourceId: toSourceId,
      amount: amount,
      description: `Transfer from ${fromSource.name}`,
      date: date,
      notes: notes,
      transferId: transferId,
    });
  };

  const getBalance = (sourceId: string) => {
    return transactions
      .filter(t => t.sourceId === sourceId)
      .reduce((acc, t) => {
        if (t.type === TransactionType.INCOME || (t.type === TransactionType.TRANSFER && t.description.includes('from'))) {
          return acc + t.amount;
        }
        return acc - t.amount; // Expense or Transfer out
      }, 0);
  };

  const getAllData = () => ({ transactions, sources, categories });

  const restoreData = (data: { transactions: Transaction[], sources: Source[], categories: Category[] }) => {
      if (data && data.transactions && data.sources && data.categories) {
          setTransactions(data.transactions);
          setSources(data.sources);
          setCategories(data.categories);
          return true;
      }
      return false;
  };

  const addSource = (name: string, icon: string) => {
    const newSource: Source = { id: uuidv4(), name, icon };
    setSources(prev => [...prev, newSource]);
  };

  const updateSource = (id: string, name: string) => {
    setSources(prev => prev.map(s => (s.id === id ? { ...s, name } : s)));
  };

  const deleteSource = (id: string) => {
    setSources(prev => prev.filter(s => s.id !== id));
    // Also delete all transactions associated with this source to prevent orphans
    setTransactions(prev => prev.filter(t => t.sourceId !== id));
  };

  const updateTransaction = (id: string, data: Partial<Omit<Transaction, 'id' | 'type' | 'transferId'>>) => {
    setTransactions(prev => 
      prev.map(t => t.id === id ? { ...t, ...data } : t)
    );
  };

  const deleteTransaction = (id: string, transferId?: string) => {
    setTransactions(prev => {
      if (transferId) {
        // If it's a transfer, remove both linked transactions
        return prev.filter(t => t.transferId !== transferId);
      }
      // Otherwise, just remove the single transaction
      return prev.filter(t => t.id !== id);
    });
  };

  const value = useMemo(() => ({
    transactions,
    sources,
    categories,
    addIncome,
    addExpense,
    addTransfer,
    getBalance,
    getAllData,
    restoreData,
    addSource,
    updateSource,
    deleteSource,
    updateTransaction,
    deleteTransaction,
  }), [transactions, sources, categories]);

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
};

export const useData = (): DataContextType => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};